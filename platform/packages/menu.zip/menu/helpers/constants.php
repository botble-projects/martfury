<?php

if (! defined('MENU_MODULE_SCREEN_NAME')) {
    define('MENU_MODULE_SCREEN_NAME', 'menu');
}

if (! defined('MENU_NODE_MODULE_SCREEN_NAME')) {
    define('MENU_NODE_MODULE_SCREEN_NAME', 'menu_node');
}

if (! defined('MENU_LOCATION_MODULE_SCREEN_NAME')) {
    define('MENU_LOCATION_MODULE_SCREEN_NAME', 'menu_location');
}

if (! defined('MENU_ACTION_SIDEBAR_OPTIONS')) {
    define('MENU_ACTION_SIDEBAR_OPTIONS', 'menu_sidebar_options');
}

if (! defined('MENU_FILTER_NODE_URL')) {
    define('MENU_FILTER_NODE_URL', 'menu_node_url');
}
