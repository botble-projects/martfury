<?php

return [
    'locations' => [],
    'cache' => [
        'enabled' => env('CACHE_FRONTEND_MENU', false),
    ],
];
