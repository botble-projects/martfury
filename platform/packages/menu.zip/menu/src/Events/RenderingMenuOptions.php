<?php

namespace Botble\Menu\Events;

use Botble\Base\Events\Event;
use Illuminate\Foundation\Events\Dispatchable;

class RenderingMenuOptions extends Event
{
    use Dispatchable;
}
