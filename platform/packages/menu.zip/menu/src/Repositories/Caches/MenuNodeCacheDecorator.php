<?php

namespace Botble\Menu\Repositories\Caches;

use Botble\Menu\Repositories\Eloquent\MenuNodeRepository;

/**
 * @deprecated
 */
class MenuNodeCacheDecorator extends MenuNodeRepository
{
}
