<?php

namespace Botble\Menu\Repositories\Caches;

use Botble\Menu\Repositories\Eloquent\MenuRepository;

/**
 * @deprecated
 */
class MenuCacheDecorator extends MenuRepository
{
}
