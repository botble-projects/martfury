<?php

namespace Botble\Menu\Repositories\Caches;

use Botble\Menu\Repositories\Eloquent\MenuLocationRepository;

/**
 * @deprecated
 */
class MenuLocationCacheDecorator extends MenuLocationRepository
{
}
